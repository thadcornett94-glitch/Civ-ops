import React from 'react';
import { LEGAL_AID_RESOURCES, US_STATES } from '../constants';

interface LegalAidFinderProps {
  onSelectAdvice: (prompt: string) => void;
}

export const LegalAidFinder: React.FC<LegalAidFinderProps> = ({ onSelectAdvice }) => {
  return (
    <div className="flex flex-col h-full overflow-y-auto animate-fade-in bg-[#f5f4f1] pb-12">
      <div className="max-w-5xl mx-auto w-full p-4 md:p-12">
        <div className="text-center mb-10">
           <div className="inline-flex items-center justify-center p-4 bg-emerald-100/80 rounded-full mb-6 shadow-sm ring-1 ring-emerald-200">
              <svg className="w-10 h-10 text-emerald-800" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
              </svg>
           </div>
           <h1 className="text-3xl md:text-5xl font-serif font-bold text-stone-900 mb-4 tracking-tight">Legal Aid & Representation</h1>
           <p className="text-stone-600 max-w-2xl mx-auto text-lg mb-8 leading-relaxed">
              Leading authority on pro-bono resources, low-cost clinics, and attorney selection strategies.
           </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
            <div className="bg-white p-8 rounded-2xl shadow-md border border-stone-200">
                <h3 className="text-xl font-serif font-bold text-stone-900 mb-4 flex items-center gap-2">
                    <span className="text-emerald-600">
                        <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                        </svg>
                    </span>
                    Professional Counselor Guide
                </h3>
                <p className="text-stone-500 text-sm mb-6">
                    Preparing for a consultation is half the battle. Use these AI guides to get the most out of your meeting.
                </p>
                <div className="space-y-3">
                    <button 
                        onClick={() => onSelectAdvice("What are the top 10 questions I should ask during an initial consultation with a lawyer to determine if they are competent and affordable?")}
                        className="w-full text-left p-3 rounded-lg border border-stone-100 hover:bg-emerald-50 hover:border-emerald-200 transition-all text-sm font-medium text-stone-700 flex items-center justify-between group"
                    >
                        Interviewing a lawyer
                        <svg className="w-4 h-4 opacity-0 group-hover:opacity-100 text-emerald-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" /></svg>
                    </button>
                    <button 
                        onClick={() => onSelectAdvice("Explain 'Contingency Fees' versus 'Hourly Rates' and 'Flat Fees'. What is standard for Personal Injury vs Criminal Defense?")}
                        className="w-full text-left p-3 rounded-lg border border-stone-100 hover:bg-emerald-50 hover:border-emerald-200 transition-all text-sm font-medium text-stone-700 flex items-center justify-between group"
                    >
                        Understanding fee structures
                        <svg className="w-4 h-4 opacity-0 group-hover:opacity-100 text-emerald-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" /></svg>
                    </button>
                    <button 
                        onClick={() => onSelectAdvice("What is the difference between a Private Lawyer and a Public Defender? How do I qualify for a Public Defender in my state?")}
                        className="w-full text-left p-3 rounded-lg border border-stone-100 hover:bg-emerald-50 hover:border-emerald-200 transition-all text-sm font-medium text-stone-700 flex items-center justify-between group"
                    >
                        Public vs Private representation
                        <svg className="w-4 h-4 opacity-0 group-hover:opacity-100 text-emerald-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" /></svg>
                    </button>
                </div>
            </div>

            <div className="bg-legal-navy p-8 rounded-2xl shadow-xl text-white relative overflow-hidden flex flex-col">
                <div className="absolute top-0 right-0 p-8 opacity-10">
                    <svg className="w-32 h-32" fill="currentColor" viewBox="0 0 24 24"><path d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" /></svg>
                </div>
                <h3 className="text-xl font-serif font-bold mb-4">State-Specific Help</h3>
                <p className="text-slate-300 text-sm mb-6 leading-relaxed">
                    Most legal aid is organized at the state and county level. Select your state to find the local Bar Association and pro-bono directories.
                </p>
                
                <div className="mt-auto">
                    <select 
                        onChange={(e) => onSelectAdvice(`Provide a detailed list of legal aid resources, pro-bono clinics, and state bar referral services for the state of ${e.target.value}. Include websites and eligibility criteria.`)}
                        className="w-full p-3 bg-white/10 border border-white/20 rounded-xl text-sm font-bold text-white outline-none mb-4"
                    >
                        <option value="" className="text-slate-900">Locate State Resources...</option>
                        {US_STATES.map(s => <option key={s} value={s} className="text-slate-900">{s}</option>)}
                    </select>
                </div>
            </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {LEGAL_AID_RESOURCES.map((resource, idx) => (
                <div key={idx} className="bg-white p-6 rounded-xl border border-stone-200 shadow-sm hover:shadow-md transition-shadow flex flex-col h-full">
                    <div className="mb-4">
                        <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-1 rounded bg-stone-100 text-stone-500">
                            {resource.category}
                        </span>
                        <h4 className="text-base font-bold text-stone-900 mt-2 line-clamp-1">{resource.name}</h4>
                    </div>
                    <p className="text-xs text-stone-500 leading-relaxed mb-6 flex-1">
                        {resource.description}
                    </p>
                    <a 
                        href={resource.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="w-full py-2 text-center bg-stone-50 border border-stone-200 rounded-lg text-xs font-bold uppercase tracking-wider text-stone-600 hover:bg-stone-900 hover:text-white hover:border-stone-900 transition-all"
                    >
                        Official Site
                    </a>
                </div>
            ))}
        </div>
      </div>
    </div>
  );
};