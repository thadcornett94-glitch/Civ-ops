import React, { useState, useRef } from 'react';
import { AppView, UserStats } from '../types';
import { ShareModal } from './ShareModal';

interface SidebarProps {
  onClear: () => void;
  isOpen: boolean;
  toggleSidebar: () => void;
  currentView: AppView;
  onChangeView: (view: AppView) => void;
  textSize: 'small' | 'normal' | 'large';
  onTextSizeChange: (size: 'small' | 'normal' | 'large') => void;
  userStats: UserStats;
  voicePreference: string;
  onVoiceChange: (voice: string) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ 
  onClear, 
  isOpen, 
  toggleSidebar, 
  currentView, 
  onChangeView, 
  textSize, 
  onTextSizeChange, 
  userStats,
  voicePreference,
  onVoiceChange
}) => {
  const [showShareModal, setShowShareModal] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const shareText = "I'm using 'The People's Law' to learn about US Law and Civil Rights. It's an AI Legal Assistant powered by Google Gemini. Check it out:";
  const shareUrl = "https://thepeopleslaw.app";

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'The People\'s Law - Legal Guide',
          text: shareText,
          url: shareUrl,
        });
        return;
      } catch (err) {}
    }
    setShowShareModal(true);
  };

  const handlePrint = () => window.print();

  const getRankColor = () => {
      switch(userStats.level) {
          case 'Partner': return 'text-purple-400';
          case 'Senior Counsel': return 'text-amber-400';
          case 'Associate': return 'text-blue-400';
          default: return 'text-stone-400';
      }
  };

  return (
    <>
      <ShareModal isOpen={showShareModal} onClose={() => setShowShareModal(false)} url={shareUrl} text={shareText} />
      <input type="file" ref={fileInputRef} className="hidden" accept=".json" />

      {isOpen && <div className="fixed inset-0 bg-stone-900/50 z-20 md:hidden backdrop-blur-sm" onClick={toggleSidebar} />}

      <aside className={`fixed md:static inset-y-0 left-0 z-30 w-64 bg-[#1c1917] text-stone-300 transform transition-transform duration-300 ease-in-out ${isOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'} flex flex-col border-r border-stone-800 shadow-2xl h-full`}>
        <div className="h-20 shrink-0 flex flex-col justify-center px-6 border-b border-stone-800 bg-[#0c0a09]">
          <div className="flex items-center gap-2 text-amber-600">
             <svg className="w-6 h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M3 6l3 1m0 0l-3 9a5.002 5.002 0 006.001 0M6 7l3 9M6 7l6-2m6 2l3-1m-3 1l-3 9a5.002 5.002 0 006.001 0M18 7l3 9m-3-9l-6-2m0-2v2m0 16V5m0 16H9m3 0h3" /></svg>
             <span className="text-lg font-serif font-bold tracking-wide text-stone-100">The People's Law</span>
          </div>
        </div>

        <div className="px-4 pt-4 pb-2 shrink-0">
            <div className="bg-stone-900 rounded-lg p-3 border border-stone-800 flex items-center gap-3 shadow-inner">
                <div className={`w-8 h-8 rounded-full border-2 border-stone-700 flex items-center justify-center bg-stone-800 ${getRankColor()}`}>
                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>
                </div>
                <div>
                    <span className={`block text-xs font-bold uppercase tracking-wider ${getRankColor()}`}>{userStats.level}</span>
                    <span className="text-[10px] text-stone-500 font-mono">{userStats.xp} XP</span>
                </div>
            </div>
        </div>

        <nav className="flex-1 overflow-y-auto py-2 px-4 space-y-1 custom-scrollbar min-h-0">
           <NavItem icon={<ChatIcon />} label="Active Session" active={currentView === 'chat'} onClick={() => { onChangeView('chat'); if (window.innerWidth < 768) toggleSidebar(); }} />
           
           <div className="text-xs font-semibold text-stone-500 uppercase tracking-wider mb-2 px-2 mt-4">Knowledge</div>
           <NavItem icon={<ScaleIcon />} label="Civil Rights Center" active={currentView === 'civil_rights'} onClick={() => { onChangeView('civil_rights'); if (window.innerWidth < 768) toggleSidebar(); }} />
           <NavItem icon={<DocIcon />} label="Founding Documents" active={currentView === 'founding_docs'} onClick={() => { onChangeView('founding_docs'); if (window.innerWidth < 768) toggleSidebar(); }} />
           <NavItem icon={<LibraryIcon />} label="Case Law Library" active={currentView === 'explorer'} onClick={() => { onChangeView('explorer'); if (window.innerWidth < 768) toggleSidebar(); }} />
           <NavItem icon={<MapIcon />} label="State Laws Index" active={currentView === 'state_laws'} onClick={() => { onChangeView('state_laws'); if (window.innerWidth < 768) toggleSidebar(); }} />
           <NavItem icon={<GavelIcon />} label="SCOTUS Docket" active={currentView === 'scotus'} onClick={() => { onChangeView('scotus'); if (window.innerWidth < 768) toggleSidebar(); }} />
           <NavItem icon={<BookIcon />} label="Legal Glossary" active={currentView === 'glossary'} onClick={() => { onChangeView('glossary'); if (window.innerWidth < 768) toggleSidebar(); }} />

           <div className="text-xs font-semibold text-stone-500 uppercase tracking-wider mb-2 mt-4 px-2">Support</div>
           <NavItem icon={<HeartIcon />} label="Find Legal Aid" active={currentView === 'legal_aid'} isHighlight onClick={() => { onChangeView('legal_aid'); if (window.innerWidth < 768) toggleSidebar(); }} />
           <NavItem icon={<PathIcon />} label="My Learning Path" active={currentView === 'learning'} onClick={() => { onChangeView('learning'); if (window.innerWidth < 768) toggleSidebar(); }} />
           <NavItem icon={<BadgeIcon />} label="Police Guide" active={currentView === 'police_guide'} isAlert onClick={() => { onChangeView('police_guide'); if (window.innerWidth < 768) toggleSidebar(); }} />

           <div className="text-xs font-semibold text-stone-500 uppercase tracking-wider mb-2 mt-4 px-2">Simulations</div>
           <NavItem icon={<UsersIcon />} label="Citizen Jury" active={currentView === 'jury'} onClick={() => { onChangeView('jury'); if (window.innerWidth < 768) toggleSidebar(); }} />
           <NavItem icon={<FireIcon />} label="Debate Dojo" active={currentView === 'debate_dojo'} onClick={() => { onChangeView('debate_dojo'); if (window.innerWidth < 768) toggleSidebar(); }} />
           <NavItem icon={<PencilIcon />} label="Document Center" active={currentView === 'drafting'} onClick={() => { onChangeView('drafting'); if (window.innerWidth < 768) toggleSidebar(); }} />
        </nav>

        <div className="shrink-0 border-t border-stone-800 bg-[#141211] p-4 space-y-4">
            <div className="grid grid-cols-2 gap-3">
                 <button onClick={handleShare} className="flex items-center justify-center gap-2 bg-stone-800 hover:bg-stone-700 text-stone-300 py-2 rounded-lg text-xs font-bold uppercase tracking-wider border border-stone-700 transition-colors">Share</button>
                 <button onClick={handlePrint} className="flex items-center justify-center gap-2 bg-stone-800 hover:bg-stone-700 text-stone-300 py-2 rounded-lg text-xs font-bold uppercase tracking-wider border border-stone-700 transition-colors">Print</button>
            </div>
        </div>
      </aside>
    </>
  );
};

const NavItem = ({ icon, label, active, onClick, isAlert, isHighlight }: any) => (
  <button 
    onClick={onClick}
    className={`w-full flex items-center gap-3 px-3 py-2.5 text-sm font-medium rounded-lg transition-colors border ${
        active 
        ? (isAlert ? 'bg-red-900/30 text-red-100 border-red-900' : isHighlight ? 'bg-emerald-900/30 text-emerald-100 border-emerald-900' : 'bg-stone-800 text-stone-100 border-stone-700') 
        : (isAlert ? 'text-red-400 hover:bg-stone-800' : isHighlight ? 'text-emerald-400 hover:bg-stone-800' : 'border-transparent text-stone-400 hover:bg-stone-800 hover:text-stone-100')
    }`}
   >
      <div className={`${active ? (isAlert ? 'text-red-400' : isHighlight ? 'text-emerald-400' : 'text-amber-600') : (isAlert ? 'text-red-500' : isHighlight ? 'text-emerald-500' : 'text-stone-500')}`}>
        {icon}
      </div>
      {label}
   </button>
);

const ChatIcon = () => <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" /></svg>;
const DocIcon = () => <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" /></svg>;
const LibraryIcon = () => <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" /></svg>;
const MapIcon = () => <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>;
const GavelIcon = () => <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 6l3 1m0 0l-3 9a5.002 5.002 0 006.001 0M6 7l3 9M6 7l6-2m6 2l3-1m-3 1l-3 9a5.002 5.002 0 006.001 0M18 7l3 9m-3-9l-6-2m0-2v2m0 16V5m0 16H9m3 0h3" /></svg>;
const BookIcon = () => <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" /></svg>;
const PathIcon = () => <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" /></svg>;
const UsersIcon = () => <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" /></svg>;
const PencilIcon = () => <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" /></svg>;
const BadgeIcon = () => <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" /></svg>;
const HeartIcon = () => <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" /></svg>;
const ScaleIcon = () => <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 6l3 1m0 0l-3 9a5.002 5.002 0 006.001 0M6 7l3 9M6 7l6-2m6 2l3-1m-3 1l-3 9a5.002 5.002 0 006.001 0M18 7l3 9m-3-9l-6-2m0-2v2m0 16V5m0 16H9m3 0h3" /></svg>;
const FireIcon = () => <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 18.657A8 8 0 016.343 7.343S7 9 9 10c0-2 .5-5 2.986-7C14 5 16.09 5.777 17.656 7.343A7.975 7.975 0 0120 13a7.975 7.975 0 01-2.343 5.657z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.879 16.121A3 3 0 1012.015 11L11 14H9c0 .768.293 1.536.879 2.121z" /></svg>;
