import React from 'react';
import { SCOTUS_CASES } from '../constants';
import { Bookmark } from '../types';

interface ScotusDocketProps {
  onSelectCase: (prompt: string) => void;
  bookmarks: Bookmark[];
  onToggleBookmark: (item: Bookmark) => void;
}

export const ScotusDocket: React.FC<ScotusDocketProps> = ({ onSelectCase, bookmarks, onToggleBookmark }) => {
  const isBookmarked = (id: string) => bookmarks.some(b => b.id === id);

  return (
    <div className="flex flex-col h-full overflow-y-auto animate-fade-in bg-[#f5f4f1] pb-12">
      <div className="max-w-4xl mx-auto w-full p-4 md:p-12">
        
        <div className="text-center mb-10">
           <div className="inline-flex items-center justify-center p-4 bg-indigo-100/80 rounded-full mb-6 shadow-sm ring-1 ring-indigo-200">
              <svg className="w-10 h-10 text-indigo-800" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M3 6l3 1m0 0l-3 9a5.002 5.002 0 006.001 0M6 7l3 9M6 7l6-2m6 2l3-1m-3 1l-3 9a5.002 5.002 0 006.001 0M18 7l3 9m-3-9l-6-2m0-2v2m0 16V5m0 16H9m3 0h3" />
              </svg>
           </div>
           <h1 className="text-3xl md:text-5xl font-serif font-bold text-stone-900 mb-4">SCOTUS Docket</h1>
           <p className="text-stone-600 max-w-2xl mx-auto text-lg mb-8">
              Recent major rulings and upcoming cases from the Supreme Court of the United States.
           </p>
        </div>

        <div className="space-y-6">
            {SCOTUS_CASES.map((scotusCase, idx) => {
                const saved = isBookmarked(scotusCase.name);
                return (
                    <div key={idx} className="bg-white rounded-xl border border-stone-200 p-6 hover:shadow-lg transition-all duration-200 group relative">
                        {/* Bookmark Button */}
                        <div className="absolute top-4 right-4">
                            <button
                                onClick={(e) => {
                                    e.stopPropagation();
                                    onToggleBookmark({
                                        id: scotusCase.name,
                                        type: 'case',
                                        title: scotusCase.name,
                                        prompt: scotusCase.prompt,
                                        subtitle: `Term ${scotusCase.term}`,
                                        timestamp: Date.now()
                                    });
                                }}
                                className={`p-2 rounded-lg transition-all ${saved ? 'text-indigo-600 bg-indigo-50' : 'text-stone-300 hover:text-indigo-500 hover:bg-indigo-50'}`}
                                title={saved ? "Remove from Briefcase" : "Save to Briefcase"}
                            >
                                <svg className="w-5 h-5" fill={saved ? "currentColor" : "none"} viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z" />
                                </svg>
                            </button>
                        </div>

                        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4 pr-12">
                            <div>
                                <span className="inline-block px-2 py-1 bg-stone-100 text-stone-500 text-xs font-bold uppercase tracking-wider rounded mb-2">
                                    Term {scotusCase.term}
                                </span>
                                <h3 className="text-xl font-serif font-bold text-stone-900 group-hover:text-indigo-900 transition-colors">
                                    {scotusCase.name}
                                </h3>
                            </div>
                            <button 
                                onClick={() => onSelectCase(scotusCase.prompt)}
                                className="shrink-0 px-4 py-2 bg-indigo-50 text-indigo-700 font-bold text-sm rounded-lg hover:bg-indigo-100 transition-colors flex items-center gap-2"
                            >
                                Analyze Ruling
                                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                                </svg>
                            </button>
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 border-t border-stone-100 pt-4">
                            <div>
                                <h4 className="text-sm font-bold text-stone-400 uppercase tracking-wider mb-2">Holding</h4>
                                <ul className="list-disc list-outside ml-4 space-y-1">
                                    {scotusCase.holding.map((item, i) => (
                                        <li key={i} className="text-stone-800 font-medium text-sm leading-relaxed">{item}</li>
                                    ))}
                                </ul>
                            </div>
                            <div>
                                <h4 className="text-sm font-bold text-stone-400 uppercase tracking-wider mb-2">Impact</h4>
                                <ul className="list-disc list-outside ml-4 space-y-1">
                                    {scotusCase.impact.map((item, i) => (
                                        <li key={i} className="text-stone-600 text-sm leading-relaxed">{item}</li>
                                    ))}
                                </ul>
                            </div>
                        </div>
                    </div>
                );
            })}
        </div>
      </div>
    </div>
  );
};