import React, { useState } from 'react';

interface EducatorModeProps {
  onSelectAction: (prompt: string) => void;
}

export const EducatorMode: React.FC<EducatorModeProps> = ({ onSelectAction }) => {
  const [gradeLevel, setGradeLevel] = useState<string>('High School');
  const [topic, setTopic] = useState<string>('');

  const tools = [
    {
      id: 'lesson',
      title: 'Lesson Plan Generator',
      description: 'Create a structured 45-minute lesson plan with learning objectives and activities.',
      icon: (
        <svg className="w-8 h-8 text-emerald-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
           <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" />
        </svg>
      )
    },
    {
      id: 'debate',
      title: 'Classroom Debate Topic',
      description: 'Generate a balanced topic with arguments for both sides to spark discussion.',
      icon: (
        <svg className="w-8 h-8 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
           <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M17 8h2a2 2 0 012 2v6a2 2 0 01-2 2h-2v4l-4-4H9a1.994 1.994 0 01-1.414-.586m0 0L11 14h4a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2v4l.586-.586z" />
        </svg>
      )
    },
    {
      id: 'simplify',
      title: 'Simplify Legal Concept',
      description: 'Explain complex case law or statutes in age-appropriate language.',
      icon: (
        <svg className="w-8 h-8 text-purple-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
           <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M13 10V3L4 14h7v7l9-11h-7z" />
        </svg>
      )
    }
  ];

  const handleAction = (type: string) => {
    if (!topic.trim()) return;

    let prompt = '';
    switch (type) {
      case 'lesson':
        prompt = `Create a 45-minute lesson plan for ${gradeLevel} students about: "${topic}". Include Learning Objectives, Key Vocabulary, a Main Activity, and Discussion Questions.`;
        break;
      case 'debate':
        prompt = `Create a classroom debate topic for ${gradeLevel} students based on: "${topic}". Provide a clear resolution statement, 3 strong arguments for the Affirmative side, and 3 strong arguments for the Negative side.`;
        break;
      case 'simplify':
        prompt = `Explain the legal concept or case of "${topic}" to a ${gradeLevel} student. Use simple language, analogies, and avoid heavy jargon. Explain why it matters to them.`;
        break;
    }
    onSelectAction(prompt);
  };

  return (
    <div className="flex flex-col h-full overflow-y-auto animate-fade-in bg-[#f5f4f1] pb-12">
      <div className="max-w-4xl mx-auto w-full p-4 md:p-12">
        
        <div className="text-center mb-10">
           <div className="inline-flex items-center justify-center p-4 bg-emerald-100/80 rounded-full mb-6 shadow-sm ring-1 ring-emerald-200">
              <svg className="w-10 h-10 text-emerald-800" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
              </svg>
           </div>
           <h1 className="text-3xl md:text-5xl font-serif font-bold text-stone-900 mb-4">Educators & Groups</h1>
           <p className="text-stone-600 max-w-2xl mx-auto text-lg mb-8">
              Tools designed for teachers, study groups, and classrooms to make US Law accessible and engaging.
           </p>
        </div>

        {/* Configuration Bar */}
        <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm mb-8 flex flex-col md:flex-row gap-4 items-center">
            <div className="flex-1 w-full">
                <label className="block text-xs font-bold uppercase tracking-wider text-stone-500 mb-2">Target Audience</label>
                <select 
                    value={gradeLevel}
                    onChange={(e) => setGradeLevel(e.target.value)}
                    className="w-full p-3 rounded-lg border border-stone-200 bg-stone-50 text-stone-800 font-medium focus:ring-2 focus:ring-emerald-500 outline-none"
                >
                    <option>Middle School (Grades 6-8)</option>
                    <option>High School (Grades 9-12)</option>
                    <option>College / Undergrad</option>
                    <option>Law Student</option>
                </select>
            </div>
            <div className="flex-[2] w-full">
                 <label className="block text-xs font-bold uppercase tracking-wider text-stone-500 mb-2">Topic or Concept</label>
                 <input 
                    type="text" 
                    value={topic}
                    onChange={(e) => setTopic(e.target.value)}
                    placeholder="e.g. The 4th Amendment, Freedom of Speech, Marbury v. Madison"
                    className="w-full p-3 rounded-lg border border-stone-200 text-stone-800 placeholder-stone-400 focus:ring-2 focus:ring-emerald-500 outline-none"
                 />
            </div>
        </div>

        {/* Tools Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {tools.map(tool => (
                <button
                    key={tool.id}
                    onClick={() => handleAction(tool.id)}
                    disabled={!topic.trim()}
                    className={`bg-white p-6 rounded-xl border border-stone-200 text-left transition-all duration-200 group flex flex-col h-full ${!topic.trim() ? 'opacity-60 cursor-not-allowed' : 'hover:shadow-lg hover:-translate-y-1 hover:border-emerald-300'}`}
                >
                    <div className="bg-stone-50 p-3 rounded-full w-fit mb-4 group-hover:bg-white group-hover:shadow-sm transition-colors">
                        {tool.icon}
                    </div>
                    <h3 className="text-lg font-serif font-bold text-stone-800 mb-2 group-hover:text-emerald-800">{tool.title}</h3>
                    <p className="text-sm text-stone-500 leading-relaxed mb-4 flex-1">
                        {tool.description}
                    </p>
                    <div className={`mt-auto text-xs font-bold uppercase tracking-wide flex items-center gap-1 ${!topic.trim() ? 'text-stone-300' : 'text-emerald-600 group-hover:text-emerald-700'}`}>
                        Generate
                        <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                             <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                        </svg>
                    </div>
                </button>
            ))}
        </div>

        <div className="mt-12 bg-emerald-50 border border-emerald-100 rounded-xl p-6">
            <h4 className="font-bold text-emerald-900 mb-2">For Study Groups</h4>
            <p className="text-emerald-800 text-sm leading-relaxed">
                Use the "Classroom Debate Topic" feature to randomly assign sides to members of your study group. 
                Have Amicus act as the moderator by asking it to "evaluate the strength of our arguments" after you present them.
            </p>
        </div>

      </div>
    </div>
  );
};
