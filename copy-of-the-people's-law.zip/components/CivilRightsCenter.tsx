import React from 'react';

interface CivilRightsCenterProps {
  onSelectTopic: (prompt: string) => void;
}

export const CivilRightsCenter: React.FC<CivilRightsCenterProps> = ({ onSelectTopic }) => {
  const rights = [
    {
      title: "Equal Protection",
      desc: "The 14th Amendment ensures no state denies any person equal protection of the laws.",
      icon: "⚖️",
      prompt: "Explain the Equal Protection Clause. How does the court apply 'Strict Scrutiny' versus 'Rational Basis'?"
    },
    {
      title: "Disability Rights (ADA)",
      desc: "Protecting individuals from discrimination in all areas of public life.",
      icon: "♿",
      prompt: "What are my rights under the Americans with Disabilities Act (ADA)? Explain public accommodations and employment protections."
    },
    {
      title: "Title IX & Education",
      desc: "No person in the US shall, on the basis of sex, be excluded from participation in education.",
      icon: "🎓",
      prompt: "Explain Title IX of the Education Amendments of 1972. How does it apply to campus sexual harassment and sports?"
    },
    {
      title: "Voting Rights",
      desc: "Protecting the fundamental right to vote from racial and linguistic discrimination.",
      icon: "🗳️",
      prompt: "What is the current status of the Voting Rights Act of 1965? Discuss Section 2 and Section 5."
    },
    {
      title: "Labor & Unions",
      desc: "The right to organize and bargain collectively for better conditions.",
      icon: "✊",
      prompt: "Explain the National Labor Relations Act (NLRA). What are my rights to form a union and engage in 'protected concerted activity'?"
    },
    {
      title: "Fair Housing (FHA)",
      desc: "Preventing discrimination in the sale, rental, and financing of housing.",
      icon: "🏠",
      prompt: "What does the Fair Housing Act prohibit? Explain 'disparate impact' in housing discrimination."
    }
  ];

  const milestones = [
    { year: "1865-70", event: "Reconstruction Amendments", desc: "13th, 14th, and 15th Amendments ratified." },
    { year: "1964", event: "Civil Rights Act", desc: "Outlawed discrimination based on race, color, religion, sex, or national origin." },
    { year: "1990", event: "ADA Signed", desc: "Major victory for the disability rights movement." },
    { year: "2020", event: "Bostock v. Clayton Co.", desc: "Extended Title VII protections to LGBTQ+ workers." }
  ];

  return (
    <div className="flex flex-col h-full overflow-y-auto animate-fade-in bg-[#fdfcf6] pb-12">
      <div className="max-w-6xl mx-auto w-full p-4 md:p-12">
        <div className="text-center mb-16 relative">
           <div className="inline-flex items-center justify-center p-5 bg-legal-navy rounded-full mb-6 shadow-2xl ring-4 ring-amber-500/20">
              <svg className="w-12 h-12 text-amber-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M3 6l3 1m0 0l-3 9a5.002 5.002 0 006.001 0M6 7l3 9M6 7l6-2m6 2l3-1m-3 1l-3 9a5.002 5.002 0 006.001 0M18 7l3 9m-3-9l-6-2m0-2v2m0 16V5m0 16H9m3 0h3" />
              </svg>
           </div>
           <h1 className="text-4xl md:text-6xl font-serif font-bold text-stone-900 mb-6 tracking-tight">Civil Rights Authority</h1>
           <p className="text-stone-600 max-w-2xl mx-auto text-xl leading-relaxed font-serif italic mb-4">
              "Injustice anywhere is a threat to justice everywhere."
           </p>
           <div className="bg-amber-100/50 border border-amber-200 p-4 rounded-xl max-w-lg mx-auto text-amber-900 text-sm font-medium">
             <strong>Quick Alert:</strong> If you believe your rights have been violated, document everything immediately—dates, names, and witnesses.
           </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
            {rights.map((r, i) => (
                <button 
                    key={i}
                    onClick={() => onSelectTopic(r.prompt)}
                    className="bg-white p-8 rounded-2xl border border-stone-200 shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all duration-300 text-left group"
                >
                    <div className="text-4xl mb-4 group-hover:scale-110 transition-transform origin-left">{r.icon}</div>
                    <h3 className="text-xl font-serif font-bold text-stone-900 mb-2 group-hover:text-amber-800 transition-colors">{r.title}</h3>
                    <p className="text-stone-500 text-sm leading-relaxed mb-6">{r.desc}</p>
                    <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-amber-700">
                        Discuss Legal Standard &rarr;
                    </div>
                </button>
            ))}
        </div>

        <div className="bg-white rounded-3xl p-8 md:p-12 border border-stone-200 shadow-md">
            <h2 className="text-3xl font-serif font-bold text-stone-900 mb-8 text-center">Timeline of Progress</h2>
            <div className="relative space-y-12">
                <div className="absolute left-1/2 top-0 bottom-0 w-px bg-stone-200 hidden md:block"></div>
                {milestones.map((m, i) => (
                    <div key={i} className={`flex flex-col md:flex-row items-center gap-8 ${i % 2 === 0 ? 'md:flex-row-reverse' : ''}`}>
                        <div className="flex-1 text-center md:text-right">
                            {i % 2 !== 0 && (
                                <>
                                    <span className="text-sm font-bold text-amber-600 uppercase tracking-widest">{m.year}</span>
                                    <h4 className="text-xl font-bold text-stone-800 mt-1">{m.event}</h4>
                                    <p className="text-sm text-stone-500 mt-2">{m.desc}</p>
                                </>
                            )}
                        </div>
                        <div className="w-4 h-4 rounded-full bg-amber-500 ring-4 ring-amber-100 z-10 shrink-0"></div>
                        <div className="flex-1 text-center md:text-left">
                            {i % 2 === 0 && (
                                <>
                                    <span className="text-sm font-bold text-amber-600 uppercase tracking-widest">{m.year}</span>
                                    <h4 className="text-xl font-bold text-stone-800 mt-1">{m.event}</h4>
                                    <p className="text-sm text-stone-500 mt-2">{m.desc}</p>
                                </>
                            )}
                        </div>
                    </div>
                ))}
            </div>
            <div className="mt-12 text-center">
                <button 
                    onClick={() => onSelectTopic("Give me a detailed timeline of civil rights in the United States, from the founding to today. Highlight the key legal victories and the heroes behind them.")}
                    className="px-8 py-4 bg-legal-navy text-white rounded-xl font-bold uppercase tracking-widest text-xs hover:bg-amber-700 transition-colors shadow-lg"
                >
                    Load Full Detailed Timeline
                </button>
            </div>
        </div>
      </div>
    </div>
  );
};