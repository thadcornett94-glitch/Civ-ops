import React, { useState } from 'react';

interface JurySimulatorProps {
  onSelectAction: (prompt: string) => void;
}

export const JurySimulator: React.FC<JurySimulatorProps> = ({ onSelectAction }) => {
  const [caseType, setCaseType] = useState<string>('criminal');

  const startSimulation = () => {
      const prompt = `
      Act as a Jury Duty Simulator for a general citizen.
      Case Type: ${caseType}.
      
      1. Generate a realistic, detailed legal case (fictional). Provide a Case Name, Facts of the Case, Prosecution/Plaintiff Argument, Defense Argument, and 3 pieces of Evidence.
      2. Explain the "Burden of Proof" required for this specific case type (e.g. Beyond Reasonable Doubt vs Preponderance of Evidence).
      3. Ask me, the Juror, to render a verdict of Guilty/Not Guilty (or Liable/Not Liable) based on the evidence provided.
      4. After I answer, provide a legal analysis of whether my verdict was reasonable based on the law.
      `;
      onSelectAction(prompt);
  };

  return (
    <div className="flex flex-col h-full overflow-y-auto animate-fade-in bg-[#f5f4f1] pb-12">
      <div className="max-w-4xl mx-auto w-full p-4 md:p-12">
        
        <div className="text-center mb-10">
           <div className="inline-flex items-center justify-center p-4 bg-stone-800 rounded-full mb-6 shadow-xl ring-4 ring-stone-300">
              <svg className="w-12 h-12 text-stone-100" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M3 6l3 1m0 0l-3 9a5.002 5.002 0 006.001 0M6 7l3 9M6 7l6-2m6 2l3-1m-3 1l-3 9a5.002 5.002 0 006.001 0M18 7l3 9m-3-9l-6-2m0-2v2m0 16V5m0 16H9m3 0h3" />
              </svg>
           </div>
           <h1 className="text-4xl md:text-5xl font-serif font-bold text-stone-900 mb-6 tracking-tight">Citizen Jury Simulator</h1>
           <p className="text-stone-600 max-w-2xl mx-auto text-xl leading-relaxed font-serif italic">
              "The jury system is the hand of the people on the scales of justice."
           </p>
        </div>

        <div className="bg-white rounded-2xl shadow-xl border border-stone-200 overflow-hidden relative">
            <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-stone-400 to-stone-600"></div>
            
            <div className="p-8 md:p-12">
                <h2 className="text-2xl font-bold text-stone-800 mb-4">Step into the Jury Box</h2>
                <p className="text-stone-600 mb-8 leading-relaxed">
                    Experience a trial from the inside. Review the evidence, hear the arguments, and apply the law. 
                    This simulator teaches you about <strong>Burden of Proof</strong>, <strong>Reasonable Doubt</strong>, and <strong>Due Process</strong> by letting you make the call.
                </p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                    <button 
                        onClick={() => setCaseType('criminal')}
                        className={`p-6 rounded-xl border-2 text-left transition-all ${caseType === 'criminal' ? 'border-stone-800 bg-stone-50' : 'border-stone-200 hover:border-stone-400'}`}
                    >
                        <div className="flex items-center gap-3 mb-2">
                             <span className={`w-4 h-4 rounded-full ${caseType === 'criminal' ? 'bg-stone-800' : 'bg-stone-300'}`}></span>
                             <h3 className="font-bold text-lg text-stone-900">Criminal Case</h3>
                        </div>
                        <p className="text-sm text-stone-500">The state vs. an individual. Standard: "Beyond a Reasonable Doubt". Higher stakes (Liberty).</p>
                    </button>

                    <button 
                        onClick={() => setCaseType('civil')}
                        className={`p-6 rounded-xl border-2 text-left transition-all ${caseType === 'civil' ? 'border-stone-800 bg-stone-50' : 'border-stone-200 hover:border-stone-400'}`}
                    >
                        <div className="flex items-center gap-3 mb-2">
                             <span className={`w-4 h-4 rounded-full ${caseType === 'civil' ? 'bg-stone-800' : 'bg-stone-300'}`}></span>
                             <h3 className="font-bold text-lg text-stone-900">Civil Lawsuit</h3>
                        </div>
                        <p className="text-sm text-stone-500">Person vs. Person. Standard: "Preponderance of the Evidence" (More likely than not). Lower stakes (Money).</p>
                    </button>
                </div>

                <div className="flex justify-center">
                    <button 
                        onClick={startSimulation}
                        className="px-8 py-4 bg-stone-900 text-white font-bold uppercase tracking-widest text-sm rounded-lg hover:bg-amber-800 transition-all shadow-lg hover:shadow-xl transform hover:-translate-y-1 flex items-center gap-3"
                    >
                        <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 6l3 1m0 0l-3 9a5.002 5.002 0 006.001 0M6 7l3 9M6 7l6-2m6 2l3-1m-3 1l-3 9a5.002 5.002 0 006.001 0M18 7l3 9m-3-9l-6-2m0-2v2m0 16V5m0 16H9m3 0h3" />
                        </svg>
                        Begin Trial Simulation
                    </button>
                </div>
            </div>
            
            <div className="bg-stone-100 px-8 py-4 border-t border-stone-200 flex justify-between items-center text-xs text-stone-500 font-mono uppercase">
                <span>Docket #2024-WTPAI</span>
                <span>Hon. We the People Presiding</span>
            </div>
        </div>

      </div>
    </div>
  );
};