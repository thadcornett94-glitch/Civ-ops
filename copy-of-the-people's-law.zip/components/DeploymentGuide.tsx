
import React, { useState } from 'react';

export const DeploymentGuide: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'money' | 'safety' | 'legal' | 'deploy'>('safety');
  const [isFounderMode, setIsFounderMode] = useState(false);
  const [clickCount, setClickCount] = useState(0);

  const handleSecretClick = () => {
      const newCount = clickCount + 1;
      setClickCount(newCount);
      if (newCount === 5) {
          setIsFounderMode(true);
          setActiveTab('deploy');
      }
  };

  return (
    <div className="flex flex-col h-full overflow-y-auto animate-fade-in bg-[#f5f4f1] pb-12">
      <div className="max-w-4xl mx-auto w-full p-4 md:p-12">
        
        <div className="text-center mb-10">
           <div 
             className={`inline-flex items-center justify-center p-4 rounded-full mb-6 shadow-sm ring-1 ring-green-200 cursor-pointer transition-colors ${isFounderMode ? 'bg-amber-100 text-amber-800' : 'bg-green-100/80 text-green-800'}`}
             onClick={handleSecretClick}
             title={isFounderMode ? "Founder Mode Active" : "About"}
           >
              <svg className="w-10 h-10" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  {isFounderMode ? (
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                  ) : (
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                  )}
              </svg>
           </div>
           <h1 className="text-3xl md:text-5xl font-serif font-bold text-stone-900 mb-4">About & Safety</h1>
           <p className="text-stone-600 max-w-2xl mx-auto text-lg mb-8">
              Transparency, safety, and legal information regarding this application.
           </p>

           <div className="flex flex-wrap justify-center gap-2 md:gap-4 mb-8">
              <button
                 onClick={() => setActiveTab('safety')}
                 className={`px-4 md:px-6 py-2 rounded-full font-bold text-xs md:text-sm uppercase tracking-wide transition-all ${
                    activeTab === 'safety' 
                    ? 'bg-amber-700 text-white shadow-md' 
                    : 'bg-white text-stone-500 border border-stone-200 hover:bg-stone-50'
                 }`}
              >
                 User Safety
              </button>
              <button
                 onClick={() => setActiveTab('legal')}
                 className={`px-4 md:px-6 py-2 rounded-full font-bold text-xs md:text-sm uppercase tracking-wide transition-all ${
                    activeTab === 'legal' 
                    ? 'bg-purple-800 text-white shadow-md' 
                    : 'bg-white text-stone-500 border border-stone-200 hover:bg-stone-50'
                 }`}
              >
                 Copyright & IP
              </button>
              
              {isFounderMode && (
                  <>
                    <button
                        onClick={() => setActiveTab('deploy')}
                        className={`px-4 md:px-6 py-2 rounded-full font-bold text-xs md:text-sm uppercase tracking-wide transition-all ${
                            activeTab === 'deploy' 
                            ? 'bg-stone-800 text-white shadow-md' 
                            : 'bg-white text-stone-500 border border-stone-200 hover:bg-stone-50'
                        }`}
                    >
                        Save Code
                    </button>
                    <button
                        onClick={() => setActiveTab('money')}
                        className={`px-4 md:px-6 py-2 rounded-full font-bold text-xs md:text-sm uppercase tracking-wide transition-all ${
                            activeTab === 'money' 
                            ? 'bg-emerald-800 text-white shadow-md' 
                            : 'bg-white text-stone-500 border border-stone-200 hover:bg-stone-50'
                        }`}
                    >
                        Business Strategy
                    </button>
                  </>
              )}
           </div>
        </div>

        {activeTab === 'money' && isFounderMode && (
            <div className="space-y-8 animate-fade-in border-4 border-emerald-500 rounded-2xl p-4">
                <div className="bg-emerald-50 border-l-4 border-emerald-500 p-6 rounded-r-xl">
                    <h2 className="text-xl font-bold text-emerald-900 mb-2">Hidden Founder Section</h2>
                    <p className="text-emerald-800">
                        This section is <strong>hidden from public users</strong>. It is only visible because you activated Founder Mode (5 clicks). 
                        You can safely share the app link; regular users will only see "User Safety" and "Copyright".
                    </p>
                </div>

                {/* The Rocket Lawyer Pitch */}
                <div className="bg-white p-8 rounded-2xl border border-stone-200 shadow-sm border-l-4 border-l-red-600">
                    <div className="flex items-center gap-3 mb-4">
                        <span className="bg-red-100 text-red-700 p-2 rounded-lg font-bold">TARGET: ROCKET LAWYER</span>
                        <h3 className="font-serif font-bold text-2xl text-stone-900">The "Lead Gen" Pitch</h3>
                    </div>
                    <p className="text-stone-500 mb-6 text-sm">
                        Rocket Lawyer makes money when people upgrade to paid memberships. This pitch positions your app as the ultimate "Free Tool" that hooks users and guides them to paid services.
                    </p>
                    
                    <div className="bg-stone-100 p-6 rounded-xl font-mono text-xs md:text-sm text-stone-700 whitespace-pre-wrap border border-stone-200">
{`SUBJECT: Acquisition Opportunity: An "Education-First" AI Front End for Rocket Lawyer

Hi [Name/Acquisitions Team],

Rocket Lawyer dominates the "Do It Yourself" legal space. But there is still a massive gap between "Searching for a form" and "Paying for a lawyer."

I built "The People's Law" to fill that gap.

It is a fully functional, React-based AI platform that uses Google Gemini 2.5 to educate users *before* they buy. It builds trust, reduces fear, and primes the user for a purchase.

THE VALUE PROPOSITION FOR ROCKET LAWYER:
1.  **Trust-Building AI:** My app uses "Safe Harbor" prompting and Google Search Grounding to answer the scary questions ("Can I be evicted?", "Am I being detained?") without liability risk. This builds the trust necessary for conversion.
2.  **The "Tutor" Funnel:** The "Tutor Mode" and "Civics Guide" keep users on the site 5x longer than a standard form download page.
3.  **Ready-to-Deploy Assets:**
    *   **50-State Police Guide:** Perfect for a "Know Your Rights" marketing campaign.
    *   **Drafting Lab:** A lightweight version of your document builder that can upsell your full suite.
    *   **Juror Simulator:** A viral marketing tool for schools/civics education.

I am looking to sell the codebase and IP as an asset acquisition. It is a plug-and-play solution to modernize your "Legal Education" center.

Price: $30,000 (Asset Sale).

Are you open to a brief demo?

Best,
[Your Name]`}
                    </div>
                </div>

                {/* The Valuation Calculator */}
                <div className="bg-white p-8 rounded-2xl border border-stone-200 shadow-sm">
                    <h3 className="font-serif font-bold text-2xl text-stone-900 mb-6">Is $30,000 too much? No.</h3>
                    <p className="text-stone-600 mb-6 text-sm">
                        Here is the math to justify a <strong>$30k</strong> asking price. This is the "Replacement Cost"—what it would cost them to build it without you at agency rates.
                    </p>
                    
                    <div className="space-y-4">
                        <div className="flex justify-between items-center p-3 bg-stone-50 rounded-lg">
                            <span className="text-stone-700 font-bold">Engineering (React/Typescript)</span>
                            <span className="text-emerald-700 font-mono font-bold">$24,000</span>
                        </div>
                        <div className="pl-4 text-xs text-stone-500 mb-2">
                            (Approx. 200 hours @ $120/hr standard agency rate for a Senior Dev to build UI, State, Audio, PDF, Share, and API logic)
                        </div>

                        <div className="flex justify-between items-center p-3 bg-stone-50 rounded-lg">
                            <span className="text-stone-700 font-bold">AI Prompt Engineering</span>
                            <span className="text-emerald-700 font-mono font-bold">$4,500</span>
                        </div>
                        <div className="pl-4 text-xs text-stone-500 mb-2">
                            (Specialized logic for "Safe Harbor", "Juror Simulation", and "Socratic Mode" - this is high-value IP)
                        </div>

                        <div className="flex justify-between items-center p-3 bg-stone-50 rounded-lg">
                            <span className="text-stone-700 font-bold">Design & Branding</span>
                            <span className="text-emerald-700 font-mono font-bold">$2,000</span>
                        </div>

                        <div className="border-t-2 border-emerald-100 mt-4 pt-4 flex justify-between items-center">
                            <span className="text-lg font-serif font-bold text-emerald-900">Total Asset Value</span>
                            <span className="text-2xl font-serif font-bold text-emerald-600">$30,500</span>
                        </div>
                    </div>
                </div>
            </div>
        )}

        {activeTab === 'safety' && (
            <div className="space-y-8 animate-fade-in">
                <div className="bg-amber-50 border-l-4 border-amber-500 p-6 rounded-r-xl">
                    <h2 className="text-xl font-bold text-amber-900 mb-2">Safety Guide</h2>
                    <p className="text-amber-800">
                        This application is designed to be a safe, private, and educational tool.
                    </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm">
                        <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center text-green-600 mb-4">
                            <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                        </div>
                        <h3 className="font-bold text-lg text-stone-900 mb-2">Privacy First</h3>
                        <p className="text-sm text-stone-600 mb-4">
                            Your conversations are stored locally on your device. We do not track your questions or report them to any agency.
                        </p>
                    </div>

                    <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm">
                        <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center text-blue-600 mb-4">
                            <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                        </div>
                        <h3 className="font-bold text-lg text-stone-900 mb-2">Educational Use</h3>
                        <p className="text-sm text-stone-600 mb-4">
                            The information provided is for educational purposes. It helps you understand the law but does not replace a lawyer.
                        </p>
                    </div>
                </div>
            </div>
        )}

        {activeTab === 'legal' && (
            <div className="space-y-8 animate-fade-in">
                <div className="bg-purple-50 border-l-4 border-purple-500 p-6 rounded-r-xl">
                    <h2 className="text-xl font-bold text-purple-900 mb-2">Copyright & Intellectual Property</h2>
                    <p className="text-purple-800">
                        Understanding rights regarding the content of this application.
                    </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm">
                        <h3 className="font-serif font-bold text-lg text-stone-900 mb-2">Public Domain</h3>
                        <ul className="text-sm text-stone-600 list-disc list-inside space-y-2">
                            <li><strong>The Law:</strong> The US Constitution, Court Cases, and Statutes are "Public Domain". They belong to the people.</li>
                            <li><strong>AI Output:</strong> Text generated by AI is generally not copyrightable.</li>
                        </ul>
                    </div>
                    <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm">
                        <h3 className="font-serif font-bold text-lg text-stone-900 mb-2">Application Rights</h3>
                        <ul className="text-sm text-stone-600 list-disc list-inside space-y-2">
                            <li><strong>The Code:</strong> The specific design and code of this tool are protected intellectual property.</li>
                            <li><strong>Brand:</strong> "The People's Law" name and logo design are trademarks of the creator.</li>
                        </ul>
                    </div>
                </div>
            </div>
        )}

        {activeTab === 'deploy' && isFounderMode && (
            <div className="animate-fade-in">
                <div className="bg-stone-800 p-6 rounded-xl text-stone-100 mb-8">
                    <h2 className="text-xl font-bold text-white mb-2">How to Save Your Code</h2>
                    <p className="text-stone-400 text-sm leading-relaxed">
                        To keep this app forever, you must save the code to your computer.
                    </p>
                </div>

                <div className="space-y-8">
                    {/* Step 1 */}
                    <div className="relative pl-8 border-l-2 border-stone-200">
                        <div className="absolute -left-[9px] top-0 w-4 h-4 rounded-full bg-stone-300"></div>
                        <h3 className="font-bold text-stone-800 text-lg mb-2">1. Download the Files</h3>
                        <p className="text-sm text-stone-600 mb-4">
                            Since you are running this in an AI chat, you must manually copy the files provided in the chat window.
                        </p>
                        <div className="bg-stone-100 p-4 rounded-lg font-mono text-xs border border-stone-200">
                            <strong>Files to Save:</strong><br/>
                            - package.json<br/>
                            - vite.config.ts<br/>
                            - index.html<br/>
                            - src/App.tsx<br/>
                            - src/constants.tsx<br/>
                            - src/types.ts<br/>
                            - src/components/*.tsx (All components)<br/>
                            - src/services/geminiService.ts
                        </div>
                    </div>

                    {/* Step 2 */}
                    <div className="relative pl-8 border-l-2 border-stone-200">
                        <div className="absolute -left-[9px] top-0 w-4 h-4 rounded-full bg-stone-300"></div>
                        <h3 className="font-bold text-stone-800 text-lg mb-2">2. Upload to GitHub</h3>
                        <p className="text-sm text-stone-600 mb-2">
                            The best way to save code permanently is <strong>GitHub.com</strong>.
                        </p>
                        <ul className="text-sm text-stone-600 list-disc list-inside space-y-1">
                            <li>Create a free account.</li>
                            <li>Create a "New Repository".</li>
                            <li>Upload your files.</li>
                        </ul>
                    </div>

                    {/* Step 3 */}
                    <div className="relative pl-8 border-l-2 border-stone-200">
                        <div className="absolute -left-[9px] top-0 w-4 h-4 rounded-full bg-stone-300"></div>
                        <h3 className="font-bold text-stone-800 text-lg mb-2">3. Deploy to Vercel (Free)</h3>
                        <p className="text-sm text-stone-600 mb-2">
                            Once your code is on GitHub, go to <strong>Vercel.com</strong>.
                        </p>
                        <ul className="text-sm text-stone-600 list-disc list-inside space-y-2">
                            <li>Click "Add New Project" -> Import from GitHub.</li>
                            <li>
                                <strong>Important:</strong> Add your Google API Key in the "Environment Variables" section as <code>API_KEY</code>.
                            </li>
                            <li>Click Deploy. Your app will be live on the internet forever!</li>
                        </ul>
                    </div>
                </div>
            </div>
        )}

      </div>
    </div>
  );
};
